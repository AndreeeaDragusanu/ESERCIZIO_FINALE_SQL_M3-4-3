use giocattoli;

-- creazione delle tabelle del database giocattoli
CREATE TABLE categoria (
    id_categoria INTEGER PRIMARY KEY,
    nome_categoria VARCHAR(40)
);
CREATE TABLE prodotti (
    id_giocattolo INTEGER PRIMARY KEY,
    id_categoria INTEGER,
    nome_giocattolo VARCHAR(40),
    FOREIGN KEY (id_categoria)
        REFERENCES categoria (id_categoria)
);

CREATE TABLE regioni (
    id_regione INTEGER PRIMARY KEY,
    nome_regione VARCHAR(40)
);

CREATE TABLE paesi (
    id_paese INTEGER PRIMARY KEY,
    id_regione INTEGER,
    nome_paese VARCHAR(40),
    FOREIGN KEY (id_regione)
        REFERENCES regioni (id_regione)
);
CREATE TABLE vendite (
    id_vendita INTEGER PRIMARY KEY,
    id_giocattolo INTEGER,
    id_regione INTEGER,
    data_vendita DATE,
    codice_fattura VARCHAR(10),
    prezzo DECIMAL(10 , 2 ),
    FOREIGN KEY (id_giocattolo)
        REFERENCES prodotti (id_giocattolo),
    FOREIGN KEY (id_regione)
        REFERENCES regioni (id_regione)
);

-- inserimento dati nelle tabelle
insert into categoria(id_categoria, nome_categoria) values
(1, 'Bambole e Peluche'),
(2, 'Giochi Prima Infanzia'),
(3, 'Giochi di Società'),
(4, 'Mattoncini e Costruzioni'),
(5, 'Puzzle');

insert into prodotti  values
(1, 1, 'Barbie Dreamhouse'),
(2, 4, 'Lego Duplo Gattino'),
(3, 1, 'Giocattolo a forma di Elefante'),
(4, 4, 'Set di Costruzione Magnetica'),
(5, 5, 'Puzzle 1000 Pezzi Città'),
(6, 1, 'Peluche Orsetto'),
(7, 2, 'Macchinina Telecomandata'),
(8, 2, 'Kit di Pittura per Bambini'),
(9, 4, 'Cubo Magico'),
(10, 3, 'Tombola');

insert into regioni (id_regione, nome_regione) values 
(1, 'Sud Europa'),
(2, 'Europa Occidentale'),
(3,'Nord Europa');

insert into paesi (id_paese,id_regione, nome_paese) values 
(1, 1, 'Italia'),
(2, 1, 'Francia'),
(3, 2, 'Germania'),
(4, 1, 'Spagna'),
(5, 2, 'Regno Unito'),
(6, 2, 'Olanda'),
(7, 3, 'Svezia'),
(8, 1, 'Portogallo');

insert into vendite (id_vendita, id_giocattolo, id_regione, codice_fattura, data_vendita, prezzo) values
(1, 1, 1, 'FAT001', '2023-09-01', 29.99),
(2, 2, 2, 'FAT002', '2023-09-05', 19.99),
(3, 3, 1, 'FAT003', '2023-09-10', 14.99),
(4, 4, 3, 'FAT004', '2023-09-15', 24.99),
(5, 5, 2, 'FAT005', '2023-09-20', 34.99),
(6, 6, 1, 'FAT006', '2023-09-25', 9.99),
(7, 7, 3, 'FAT007', '2023-10-01', 39.99),
(8, 8, 2, 'FAT008', '2023-10-05', 17.99),
(9, 9, 1, 'FAT009', '2023-10-10', 12.99),
(10, 10, 3, 'FAT010', '2023-10-15', 22.99),
(11, 1, 2, 'FAT011', '2023-10-20', 29.99),
(12, 2, 1, 'FAT012', '2023-10-25', 19.99),
(13, 3, 3, 'FAT013', '2023-11-01', 14.99),
(14, 4, 2, 'FAT014', '2023-11-05', 24.99),
(15, 5, 1, 'FAT015', '2023-11-10', 34.99),
(16, 6, 3, 'FAT016', '2023-11-15', 9.99),
(17, 7, 1, 'FAT017', '2023-11-20', 39.99),
(18, 8, 2, 'FAT018', '2023-11-25', 17.99),
(19, 9, 3, 'FAT019', '2023-12-01', 12.99),
(20, 10, 1, 'FAT020', '2023-12-05', 22.99),
(21, 1, 3, 'FAT021', '2023-12-10', 29.99),
(22, 2, 2, 'FAT022', '2023-12-15', 19.99),
(23, 3, 1, 'FAT023', '2023-12-20', 14.99),
(24, 4, 3, 'FAT024', '2023-12-25', 24.99),
(25, 5, 2, 'FAT025', '2024-01-01', 34.99),
(26, 6, 1, 'FAT026', '2024-01-05', 9.99),
(27, 7, 3, 'FAT027', '2024-01-10', 39.99),
(28, 8, 2, 'FAT028', '2024-01-15', 17.99),
(29, 9, 1, 'FAT029', '2024-01-20', 12.99),
(30, 10, 3, 'FAT030', '2024-01-25', 22.99);


-- 1. Verificare che i campi definiti come PK siano univoci.
-- I campi definiti come PRIMARY KEY sono univoci in quanto il vincolo PK garantisce univocita dei campi.

-- query per la tabella categoria 
SELECT 
    id_categoria, COUNT(*) AS conteggio
FROM
    categoria
GROUP BY id_categoria
HAVING COUNT(*) > 1;
-- non avendo risultati vuol dire che 'id_categoria' ha soltanto valori univoci


-- query per la tabella prodotti
SELECT 
    id_giocattolo, COUNT(*) conteggio
FROM
    prodotti
GROUP BY id_giocattolo
HAVING COUNT(*) > 1;

-- query tabella paesi
SELECT 
    id_paese, COUNT(*) conteggio
FROM
    paesi
GROUP BY id_paese
HAVING COUNT(*) > 1;

-- query tabella regioni
SELECT 
    id_regione, COUNT(*) conteggio
FROM
    regioni
GROUP BY id_regione
HAVING COUNT(*) > 1;

-- query tabella vendite
SELECT 
    id_vendita, COUNT(*) conteggio
FROM
    vendite
GROUP BY id_vendita
HAVING COUNT(*) > 1;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT 
    prodotti.nome_giocattolo giocattolo,
    YEAR(data_vendita) anno,
    SUM(vendite.prezzo) fatturato
FROM
    prodotti
        JOIN
    vendite USING (id_giocattolo)
GROUP BY giocattolo , anno
ORDER BY anno;

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
SELECT 
    paesi.nome_paese paese,
    SUM(vendite.prezzo) fatturato,
    YEAR(data_vendita) anno
FROM
    vendite
        JOIN
    paesi USING (id_regione)
GROUP BY anno , paese
ORDER BY anno , fatturato DESC;

-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT 
    categoria.nome_categoria categoria,
    COUNT(id_giocattolo) richiesta
FROM
    categoria
        JOIN
    prodotti USING (id_categoria)
        JOIN
    vendite USING (id_giocattolo)
GROUP BY categoria
ORDER BY richiesta DESC
LIMIT 1;
-- visto il caso sarebbe piu giusto fare limit 2 perche ci sono due valori massimi uguali.
SELECT 
    categoria.nome_categoria categoria,
    COUNT(id_giocattolo) richiesta
FROM
    categoria
        JOIN
    prodotti USING (id_categoria)
        JOIN
    vendite USING (id_giocattolo)
GROUP BY categoria
ORDER BY richiesta DESC
LIMIT 2;

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- 1 utilizzo di una query annidata
SELECT 
    prodotti.id_giocattolo, prodotti.nome_giocattolo giocattolo
FROM
    prodotti
WHERE
    id_giocattolo NOT IN (SELECT 
            id_giocattolo
        FROM
            vendite);
		
-- 2 utilizzo di una left join
SELECT 
    prodotti.id_giocattolo, prodotti.nome_giocattolo
FROM
    prodotti
        LEFT JOIN
    vendite USING (id_giocattolo)
WHERE
    vendite.id_vendita IS NULL;
    
-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)
SELECT 
    prodotti.nome_giocattolo giocattolo,
    MAX(vendite.data_vendita) ultimadatavendita
FROM
    prodotti
        JOIN
    vendite USING (id_giocattolo)
GROUP BY giocattolo;

-- BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita
--  e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
SELECT 
    vendite.codice_fattura fattura,
    vendite.data_vendita data,
    prodotti.nome_giocattolo articolo,
    categoria.nome_categoria categoria,
    paesi.nome_paese paese,
    regioni.nome_regione regione,
    CASE
        WHEN DATEDIFF(NOW(), vendite.data_vendita) > 180 THEN 'vero'
        ELSE 'falso'
    END piu_180_gg
FROM
    categoria
        JOIN
    prodotti USING (id_categoria)
        JOIN
    vendite USING (id_giocattolo)
        JOIN
    regioni USING (id_regione)
        JOIN
    paesi USING (id_regione);